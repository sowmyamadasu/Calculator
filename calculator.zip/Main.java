public class Calculator
{
    int addition(int num1,int num2){
     return num1 + num2;   
    }
    int subtraction(int num1,int num2){
     return num1 - num2;    
    }
    int multiplication(int num1,int num2){
     return num1 * num2;   
    }
   int division(int num1,int num2){
     return num1 / num2;    
    }
    int modulous(int num1,int num2){
     return num1 % num2;   
    }
    import java.util.Scanner;
    public static void main(String[] args) {
        
		Scanner scanner=new Scanner(System.in);
		Calculator cal=new Calculator();
		System.out.println("Enter two numbers");
		System.out.println("Addition result is: "+cal.addition(scan.nextInt(),scan.nextInt()));
		
		System.out.println("Enter two numbers");
		System.out.println("subtraction result is: "+cal.subtraction(scan.nextInt(),scan.nextInt()));
		
		System.out.println("Enter two numbers");
		System.out.println("Multiplication result is: "+cal.multiplication(scan.nextInt(),scan.nextInt()));
		
		System.out.println("Enter two numbers");
		System.out.println("Division result is: "+cal.division(scan.nextInt(),scan.nextInt()));
		
		System.out.println("Enter two numbers");
		System.out.println("modulous result is: "+cal.modulous(scan.nextInt(),scan.nextInt()));
}  
	
}